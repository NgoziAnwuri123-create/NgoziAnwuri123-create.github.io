## Predicting Customer Churn by Ngozi Anwuri


```python
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd 
```


```python
data = pd.read_csv(r"C:\Users\CharlesQ\Downloads\ecoms_customer_data.csv")
```


```python
data = data.to_csv(r"C:\Users\CharlesQ\Downloads\ecoms_customer_data.csv", index= False)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer_ID</th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Location_Region</th>
      <th>Marital_Status</th>
      <th>Annual_Income</th>
      <th>Membership_Tier</th>
      <th>Join_Date</th>
      <th>Last_Login_Date</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
      <th>Preferred_Device</th>
      <th>Payment_Method</th>
      <th>Marketing_Opt_In</th>
      <th>Last_Feedback_Text</th>
      <th>Discount_Code_Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CUST_00000</td>
      <td>0</td>
      <td>45</td>
      <td>Female</td>
      <td>West</td>
      <td>Divorced</td>
      <td>79239.91</td>
      <td>Silver</td>
      <td>16/10/2021</td>
      <td>02/11/2023</td>
      <td>944.99</td>
      <td>6</td>
      <td>12.1</td>
      <td>0</td>
      <td>Desktop</td>
      <td>COD</td>
      <td>True</td>
      <td>Great service!</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CUST_00001</td>
      <td>1</td>
      <td>24</td>
      <td>Female</td>
      <td>East</td>
      <td>Married</td>
      <td>67390.43</td>
      <td>Platinum</td>
      <td>24/04/2020</td>
      <td>02/01/2023</td>
      <td>45.50</td>
      <td>5</td>
      <td>19.1</td>
      <td>2</td>
      <td>Tablet</td>
      <td>PayPal</td>
      <td>False</td>
      <td>Too expensive.</td>
      <td>SAVE10</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CUST_00002</td>
      <td>0</td>
      <td>52</td>
      <td>Female</td>
      <td>East</td>
      <td>Married</td>
      <td>96437.88</td>
      <td>Platinum</td>
      <td>26/01/2020</td>
      <td>22/05/2023</td>
      <td>1394.82</td>
      <td>13</td>
      <td>9.1</td>
      <td>1</td>
      <td>Mobile</td>
      <td>PayPal</td>
      <td>False</td>
      <td>Worst experience ever.</td>
      <td>SUMMER20</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CUST_00003</td>
      <td>0</td>
      <td>45</td>
      <td>Male</td>
      <td>South</td>
      <td>Married</td>
      <td>31695.81</td>
      <td>Platinum</td>
      <td>29/01/2022</td>
      <td>16/03/2023</td>
      <td>82.44</td>
      <td>0</td>
      <td>11.9</td>
      <td>2</td>
      <td>Tablet</td>
      <td>PayPal</td>
      <td>True</td>
      <td>Great service!</td>
      <td>SAVE10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CUST_00004</td>
      <td>0</td>
      <td>31</td>
      <td>Female</td>
      <td>East</td>
      <td>Divorced</td>
      <td>47409.48</td>
      <td>Gold</td>
      <td>08/10/2020</td>
      <td>08/03/2023</td>
      <td>1068.49</td>
      <td>16</td>
      <td>6.1</td>
      <td>2</td>
      <td>Tablet</td>
      <td>Credit Card</td>
      <td>False</td>
      <td>Too expensive.</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2000 entries, 0 to 1999
    Data columns (total 19 columns):
     #   Column                    Non-Null Count  Dtype  
    ---  ------                    --------------  -----  
     0   Customer_ID               2000 non-null   object 
     1   Churn_Label               2000 non-null   int64  
     2   Age                       2000 non-null   int64  
     3   Gender                    1959 non-null   object 
     4   Location_Region           2000 non-null   object 
     5   Marital_Status            2000 non-null   object 
     6   Annual_Income             2000 non-null   float64
     7   Membership_Tier           2000 non-null   object 
     8   Join_Date                 2000 non-null   object 
     9   Last_Login_Date           2000 non-null   object 
     10  Total_Spend_Lifetime      2000 non-null   float64
     11  Items_In_Cart             2000 non-null   int64  
     12  Avg_Session_Duration_Min  2000 non-null   float64
     13  Customer_Support_Calls    2000 non-null   int64  
     14  Preferred_Device          2000 non-null   object 
     15  Payment_Method            2000 non-null   object 
     16  Marketing_Opt_In          2000 non-null   bool   
     17  Last_Feedback_Text        1723 non-null   object 
     18  Discount_Code_Used        1492 non-null   object 
    dtypes: bool(1), float64(3), int64(4), object(11)
    memory usage: 283.3+ KB
    

#### The data has missing values in gender, last feedback txt and discount code
#### I will drop irrelevant columns such as customer id to optimise the model 


```python
data.drop('Customer_ID', axis = 1, inplace = True)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Location_Region</th>
      <th>Marital_Status</th>
      <th>Annual_Income</th>
      <th>Membership_Tier</th>
      <th>Join_Date</th>
      <th>Last_Login_Date</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
      <th>Preferred_Device</th>
      <th>Payment_Method</th>
      <th>Marketing_Opt_In</th>
      <th>Last_Feedback_Text</th>
      <th>Discount_Code_Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>45</td>
      <td>Female</td>
      <td>West</td>
      <td>Divorced</td>
      <td>79239.91</td>
      <td>Silver</td>
      <td>16/10/2021</td>
      <td>02/11/2023</td>
      <td>944.99</td>
      <td>6</td>
      <td>12.1</td>
      <td>0</td>
      <td>Desktop</td>
      <td>COD</td>
      <td>True</td>
      <td>Great service!</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>24</td>
      <td>Female</td>
      <td>East</td>
      <td>Married</td>
      <td>67390.43</td>
      <td>Platinum</td>
      <td>24/04/2020</td>
      <td>02/01/2023</td>
      <td>45.50</td>
      <td>5</td>
      <td>19.1</td>
      <td>2</td>
      <td>Tablet</td>
      <td>PayPal</td>
      <td>False</td>
      <td>Too expensive.</td>
      <td>SAVE10</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>52</td>
      <td>Female</td>
      <td>East</td>
      <td>Married</td>
      <td>96437.88</td>
      <td>Platinum</td>
      <td>26/01/2020</td>
      <td>22/05/2023</td>
      <td>1394.82</td>
      <td>13</td>
      <td>9.1</td>
      <td>1</td>
      <td>Mobile</td>
      <td>PayPal</td>
      <td>False</td>
      <td>Worst experience ever.</td>
      <td>SUMMER20</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>45</td>
      <td>Male</td>
      <td>South</td>
      <td>Married</td>
      <td>31695.81</td>
      <td>Platinum</td>
      <td>29/01/2022</td>
      <td>16/03/2023</td>
      <td>82.44</td>
      <td>0</td>
      <td>11.9</td>
      <td>2</td>
      <td>Tablet</td>
      <td>PayPal</td>
      <td>True</td>
      <td>Great service!</td>
      <td>SAVE10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>31</td>
      <td>Female</td>
      <td>East</td>
      <td>Divorced</td>
      <td>47409.48</td>
      <td>Gold</td>
      <td>08/10/2020</td>
      <td>08/03/2023</td>
      <td>1068.49</td>
      <td>16</td>
      <td>6.1</td>
      <td>2</td>
      <td>Tablet</td>
      <td>Credit Card</td>
      <td>False</td>
      <td>Too expensive.</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
## Clean data by addressing missing values 

data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Annual_Income</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2000.000000</td>
      <td>2000.000000</td>
      <td>2000.000000</td>
      <td>2000.000000</td>
      <td>2000.00000</td>
      <td>2000.000000</td>
      <td>2000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.201500</td>
      <td>43.715500</td>
      <td>54969.300590</td>
      <td>989.459145</td>
      <td>12.02850</td>
      <td>15.013600</td>
      <td>1.046500</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.401221</td>
      <td>14.965311</td>
      <td>14876.354589</td>
      <td>970.356719</td>
      <td>7.09527</td>
      <td>4.990222</td>
      <td>1.049232</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>18.000000</td>
      <td>-449.330000</td>
      <td>1.090000</td>
      <td>0.00000</td>
      <td>-1.900000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000000</td>
      <td>31.000000</td>
      <td>44843.660000</td>
      <td>291.097500</td>
      <td>6.00000</td>
      <td>11.775000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.000000</td>
      <td>44.000000</td>
      <td>55310.210000</td>
      <td>698.840000</td>
      <td>12.00000</td>
      <td>15.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>0.000000</td>
      <td>57.000000</td>
      <td>65051.200000</td>
      <td>1370.837500</td>
      <td>18.00000</td>
      <td>18.300000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.000000</td>
      <td>69.000000</td>
      <td>106212.810000</td>
      <td>7917.330000</td>
      <td>24.00000</td>
      <td>31.900000</td>
      <td>7.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.isnull().mean()*100
```




    Churn_Label                  0.00
    Age                          0.00
    Gender                       2.05
    Location_Region              0.00
    Marital_Status               0.00
    Annual_Income                0.00
    Membership_Tier              0.00
    Join_Date                    0.00
    Last_Login_Date              0.00
    Total_Spend_Lifetime         0.00
    Items_In_Cart                0.00
    Avg_Session_Duration_Min     0.00
    Customer_Support_Calls       0.00
    Preferred_Device             0.00
    Payment_Method               0.00
    Marketing_Opt_In             0.00
    Last_Feedback_Text          13.85
    Discount_Code_Used          25.40
    dtype: float64




```python
## To maintain the quality of data I will drop missing values from the data 

```


```python
dataclean = data.dropna()
```


```python
dataclean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 1256 entries, 1 to 1996
    Data columns (total 18 columns):
     #   Column                    Non-Null Count  Dtype  
    ---  ------                    --------------  -----  
     0   Churn_Label               1256 non-null   int64  
     1   Age                       1256 non-null   int64  
     2   Gender                    1256 non-null   object 
     3   Location_Region           1256 non-null   object 
     4   Marital_Status            1256 non-null   object 
     5   Annual_Income             1256 non-null   float64
     6   Membership_Tier           1256 non-null   object 
     7   Join_Date                 1256 non-null   object 
     8   Last_Login_Date           1256 non-null   object 
     9   Total_Spend_Lifetime      1256 non-null   float64
     10  Items_In_Cart             1256 non-null   int64  
     11  Avg_Session_Duration_Min  1256 non-null   float64
     12  Customer_Support_Calls    1256 non-null   int64  
     13  Preferred_Device          1256 non-null   object 
     14  Payment_Method            1256 non-null   object 
     15  Marketing_Opt_In          1256 non-null   bool   
     16  Last_Feedback_Text        1256 non-null   object 
     17  Discount_Code_Used        1256 non-null   object 
    dtypes: bool(1), float64(3), int64(4), object(10)
    memory usage: 177.9+ KB
    

## Encoding catergorical data using label encoder


```python
from sklearn.preprocessing import LabelEncoder
## intialise encoder 

encoder = LabelEncoder()
```


```python
data['Gender'] = encoder.fit_transform(data['Gender'])
data['Location_Region'] = encoder.fit_transform(data['Location_Region'])
data['Marital_Status'] = encoder.fit_transform(data['Marital_Status'])
data['Membership_Tier'] = encoder.fit_transform(data['Membership_Tier'])
data['Preferred_Device'] = encoder.fit_transform(data['Preferred_Device'])
data['Payment_Method'] = encoder.fit_transform(data['Payment_Method'])
data['Marketing_Opt_In'] = encoder.fit_transform(data['Marketing_Opt_In'])
data['Last_Feedback_Text'] = encoder.fit_transform(data['Last_Feedback_Text'])
data['Discount_Code_Used'] = encoder.fit_transform(data['Discount_Code_Used'])
data['Join_Date'] = encoder.fit_transform(data['Join_Date'])
data['Last_Login_Date'] = encoder.fit_transform(data['Last_Login_Date'])
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Location_Region</th>
      <th>Marital_Status</th>
      <th>Annual_Income</th>
      <th>Membership_Tier</th>
      <th>Join_Date</th>
      <th>Last_Login_Date</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
      <th>Preferred_Device</th>
      <th>Payment_Method</th>
      <th>Marketing_Opt_In</th>
      <th>Last_Feedback_Text</th>
      <th>Discount_Code_Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>24</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>67390.43</td>
      <td>2</td>
      <td>565</td>
      <td>12</td>
      <td>45.50</td>
      <td>5</td>
      <td>19.1</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>52</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>96437.88</td>
      <td>2</td>
      <td>602</td>
      <td>250</td>
      <td>1394.82</td>
      <td>13</td>
      <td>9.1</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>45</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>31695.81</td>
      <td>2</td>
      <td>677</td>
      <td>176</td>
      <td>82.44</td>
      <td>0</td>
      <td>11.9</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0</td>
      <td>33</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>73440.52</td>
      <td>0</td>
      <td>378</td>
      <td>98</td>
      <td>1783.13</td>
      <td>13</td>
      <td>21.4</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>33</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>51691.74</td>
      <td>2</td>
      <td>519</td>
      <td>351</td>
      <td>192.01</td>
      <td>9</td>
      <td>13.4</td>
      <td>0</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>5</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



## Scale the features 


```python
## Check the distibution of the data 
fig, ax = plt.subplots(6, 3, figsize=(20,20))

ax=ax.flatten()
for idx, col in enumerate(dataclean):
    sns.histplot (dataclean[col], ax = ax[idx], color = "green", kde = True, bins = 30)
    plt.tight_layout()
    plt.show
    
```


    
![png](output_19_0.png)
    



```python
## check distribution and box plot 
fig, ax = plt.subplots(6, 3, figsize=(20,20))

ax=ax.flatten()
for idx, col in enumerate(dataclean):
    sns.boxplot (dataclean[col], ax = ax[idx], color = "teal",)
    plt.tight_layout()
    plt.show
```


    
![png](output_20_0.png)
    



```python

```
## Dealing with outliers in the data 

## outliers can be seen in churn lavel, gender, annual income, customer support call, average sesson duration


```python
affected_columns =['Gender', 'Annual_Income','Customer_Support_Calls','Avg_Session_Duration_Min']

q1 = data[affected_columns].quantile(0.25)

q3 = data[affected_columns].quantile(0.75)

iqr = q3 - q1 

lower_bound = q1 - 1.5*iqr
upper_bound = q3 + 1.5*iqr 

data = data[affected_columns].clip(lower_bound, upper_bound, axis = 1)
```


```python
## check outliers 
fig, ax = plt.subplots(2, 2, figsize=(15,10))

ax=ax.flatten()
for idx, col in enumerate(data):
    sns.boxplot (data[col], ax = ax[idx], color = "seagreen",)
    plt.tight_layout()
    plt.show
```


    
![png](output_24_0.png)
    


## Scaling numerical features 


```python
data = dataclean
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Location_Region</th>
      <th>Marital_Status</th>
      <th>Annual_Income</th>
      <th>Membership_Tier</th>
      <th>Join_Date</th>
      <th>Last_Login_Date</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
      <th>Preferred_Device</th>
      <th>Payment_Method</th>
      <th>Marketing_Opt_In</th>
      <th>Last_Feedback_Text</th>
      <th>Discount_Code_Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>24</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>67390.43</td>
      <td>2</td>
      <td>565</td>
      <td>12</td>
      <td>45.50</td>
      <td>5</td>
      <td>19.1</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>52</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>96437.88</td>
      <td>2</td>
      <td>602</td>
      <td>250</td>
      <td>1394.82</td>
      <td>13</td>
      <td>9.1</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>45</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>31695.81</td>
      <td>2</td>
      <td>677</td>
      <td>176</td>
      <td>82.44</td>
      <td>0</td>
      <td>11.9</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0</td>
      <td>33</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>73440.52</td>
      <td>0</td>
      <td>378</td>
      <td>98</td>
      <td>1783.13</td>
      <td>13</td>
      <td>21.4</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>33</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>51691.74</td>
      <td>2</td>
      <td>519</td>
      <td>351</td>
      <td>192.01</td>
      <td>9</td>
      <td>13.4</td>
      <td>0</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>5</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
num_col_to_scale= ['Age','Annual_Income','Join_Date','Last_Login_Date','Total_Spend_Lifetime','Items_In_Cart','Avg_Session_Duration_Min','Last_Feedback_Text']
```


```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
```


```python
data[num_col_to_scale] = scaler.fit_transform(data[num_col_to_scale])
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Location_Region</th>
      <th>Marital_Status</th>
      <th>Annual_Income</th>
      <th>Membership_Tier</th>
      <th>Join_Date</th>
      <th>Last_Login_Date</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
      <th>Preferred_Device</th>
      <th>Payment_Method</th>
      <th>Marketing_Opt_In</th>
      <th>Last_Feedback_Text</th>
      <th>Discount_Code_Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>-1.338507</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.826417</td>
      <td>2</td>
      <td>0.923303</td>
      <td>-1.598214</td>
      <td>-0.971282</td>
      <td>-0.958559</td>
      <td>0.842524</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>0.977540</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.522586</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2.750678</td>
      <td>2</td>
      <td>1.096337</td>
      <td>0.716785</td>
      <td>0.405236</td>
      <td>0.175104</td>
      <td>-1.181364</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>1.482180</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0.057312</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>-1.538189</td>
      <td>2</td>
      <td>1.447082</td>
      <td>-0.003005</td>
      <td>-0.933597</td>
      <td>-1.667099</td>
      <td>-0.614676</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>-0.536381</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0</td>
      <td>-0.740299</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1.227208</td>
      <td>0</td>
      <td>0.048780</td>
      <td>-0.761702</td>
      <td>0.801374</td>
      <td>0.175104</td>
      <td>1.308018</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>-0.031741</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>-0.740299</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>-0.213550</td>
      <td>2</td>
      <td>0.708180</td>
      <td>1.699200</td>
      <td>-0.821818</td>
      <td>-0.391728</td>
      <td>-0.311092</td>
      <td>0</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0.977540</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
data["Churn_Label"].value_counts()
data["Churn_Label"].value_counts(normalize = True)*100
```




    Churn_Label
    0    79.219745
    1    20.780255
    Name: proportion, dtype: float64




```python
## To assess the balance of the target the target variable 

plt.figure(figsize = (6,3))
sns.countplot(x=data["Churn_Label"]);
```


    
![png](output_33_0.png)
    



```python
# To address the impbalance in the data set 
!pip install imbalanced_learn
```

    Requirement already satisfied: imbalanced_learn in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (0.14.0)
    Requirement already satisfied: numpy<3,>=1.25.2 in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from imbalanced_learn) (2.3.5)
    Requirement already satisfied: scipy<2,>=1.11.4 in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from imbalanced_learn) (1.16.3)
    Requirement already satisfied: scikit-learn<2,>=1.4.2 in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from imbalanced_learn) (1.7.2)
    Requirement already satisfied: joblib<2,>=1.2.0 in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from imbalanced_learn) (1.5.2)
    Requirement already satisfied: threadpoolctl<4,>=2.0.0 in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from imbalanced_learn) (3.5.0)
    


```python
from imblearn.over_sampling import SMOTE

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn_Label</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Location_Region</th>
      <th>Marital_Status</th>
      <th>Annual_Income</th>
      <th>Membership_Tier</th>
      <th>Join_Date</th>
      <th>Last_Login_Date</th>
      <th>Total_Spend_Lifetime</th>
      <th>Items_In_Cart</th>
      <th>Avg_Session_Duration_Min</th>
      <th>Customer_Support_Calls</th>
      <th>Preferred_Device</th>
      <th>Payment_Method</th>
      <th>Marketing_Opt_In</th>
      <th>Last_Feedback_Text</th>
      <th>Discount_Code_Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>-1.338507</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0.826417</td>
      <td>2</td>
      <td>0.923303</td>
      <td>-1.598214</td>
      <td>-0.971282</td>
      <td>-0.958559</td>
      <td>0.842524</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>0.977540</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.522586</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2.750678</td>
      <td>2</td>
      <td>1.096337</td>
      <td>0.716785</td>
      <td>0.405236</td>
      <td>0.175104</td>
      <td>-1.181364</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>1.482180</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0.057312</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>-1.538189</td>
      <td>2</td>
      <td>1.447082</td>
      <td>-0.003005</td>
      <td>-0.933597</td>
      <td>-1.667099</td>
      <td>-0.614676</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>-0.536381</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0</td>
      <td>-0.740299</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1.227208</td>
      <td>0</td>
      <td>0.048780</td>
      <td>-0.761702</td>
      <td>0.801374</td>
      <td>0.175104</td>
      <td>1.308018</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>-0.031741</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>-0.740299</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>-0.213550</td>
      <td>2</td>
      <td>0.708180</td>
      <td>1.699200</td>
      <td>-0.821818</td>
      <td>-0.391728</td>
      <td>-0.311092</td>
      <td>0</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0.977540</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
from imblearn.over_sampling import SMOTE

X = data.drop("Churn_Label", axis = 1)

y= data["Churn_Label"]


y.head()
```




    1    1
    2    0
    3    0
    6    0
    7    1
    Name: Churn_Label, dtype: int64




```python
smote = SMOTE(random_state = 42)

X, y = smote.fit_resample(X,y)

y.value_counts(normalize= True)
#### The data has been splt into 805 training set and 205 test set, by smoting the target variable we have improved
#### the model predictive capability

sns.countplot(x=y)
```




    <Axes: xlabel='Churn_Label', ylabel='count'>




    
![png](output_37_1.png)
    



```python

y.value_counts()

```




    Churn_Label
    1    995
    0    995
    Name: count, dtype: int64




```python
## To split the data set in 20 to 80 split

from sklearn.model_selection import train_test_split


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42)
```


```python
## check the values of train and test data 
print(f"Train {len(X_train)}")
print(f"Test {len(X_test)}")
```

    Train 1592
    Test 398
    


```python
y_train.value_counts(normalize = True)*100
```




    Churn_Label
    0    51.130653
    1    48.869347
    Name: proportion, dtype: float64




```python
##Model selection and fitting 

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier,AdaBoostClassifier
from sklearn.linear_model import LogisticRegression 
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

!pip install xgboost

```

    Requirement already satisfied: xgboost in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (3.2.0)
    Requirement already satisfied: numpy in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from xgboost) (2.3.5)
    Requirement already satisfied: scipy in c:\users\charlesq\appdata\local\anaconda3\lib\site-packages (from xgboost) (1.16.3)
    


```python
from xgboost import XGBClassifier 
```

## Training advanced models 


```python
## initialising model
LG_MODEL = LogisticRegression(random_state = 42)

## model training 
LG_MODEL.fit(X_train, y_train)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: #000;
  --sklearn-color-text-muted: #666;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: flex;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
  align-items: start;
  justify-content: space-between;
  gap: 0.5em;
}

#sk-container-id-1 label.sk-toggleable__label .caption {
  font-size: 0.6rem;
  font-weight: lighter;
  color: var(--sklearn-color-text-muted);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  display: none;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  display: block;
  width: 100%;
  overflow: visible;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 0.5em;
  text-align: center;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}

.estimator-table summary {
    padding: .5rem;
    font-family: monospace;
    cursor: pointer;
}

.estimator-table details[open] {
    padding-left: 0.1rem;
    padding-right: 0.1rem;
    padding-bottom: 0.3rem;
}

.estimator-table .parameters-table {
    margin-left: auto !important;
    margin-right: auto !important;
}

.estimator-table .parameters-table tr:nth-child(odd) {
    background-color: #fff;
}

.estimator-table .parameters-table tr:nth-child(even) {
    background-color: #f6f6f6;
}

.estimator-table .parameters-table tr:hover {
    background-color: #e0e0e0;
}

.estimator-table table td {
    border: 1px solid rgba(106, 105, 104, 0.232);
}

.user-set td {
    color:rgb(255, 94, 0);
    text-align: left;
}

.user-set td.value pre {
    color:rgb(255, 94, 0) !important;
    background-color: transparent !important;
}

.default td {
    color: black;
    text-align: left;
}

.user-set td i,
.default td i {
    color: black;
}

.copy-paste-icon {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NDggNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNy4yIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjUgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTIwOCAwTDMzMi4xIDBjMTIuNyAwIDI0LjkgNS4xIDMzLjkgMTQuMWw2Ny45IDY3LjljOSA5IDE0LjEgMjEuMiAxNC4xIDMzLjlMNDQ4IDMzNmMwIDI2LjUtMjEuNSA0OC00OCA0OGwtMTkyIDBjLTI2LjUgMC00OC0yMS41LTQ4LTQ4bDAtMjg4YzAtMjYuNSAyMS41LTQ4IDQ4LTQ4ek00OCAxMjhsODAgMCAwIDY0LTY0IDAgMCAyNTYgMTkyIDAgMC0zMiA2NCAwIDAgNDhjMCAyNi41LTIxLjUgNDgtNDggNDhMNDggNTEyYy0yNi41IDAtNDgtMjEuNS00OC00OEwwIDE3NmMwLTI2LjUgMjEuNS00OCA0OC00OHoiLz48L3N2Zz4=);
    background-repeat: no-repeat;
    background-size: 14px 14px;
    background-position: 0;
    display: inline-block;
    width: 14px;
    height: 14px;
    cursor: pointer;
}
</style><body><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow"><div><div>LogisticRegression</div></div><div><a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.7/modules/generated/sklearn.linear_model.LogisticRegression.html">?<span>Documentation for LogisticRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></div></label><div class="sk-toggleable__content fitted" data-param-prefix="">
        <div class="estimator-table">
            <details>
                <summary>Parameters</summary>
                <table class="parameters-table">
                  <tbody>

        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('penalty',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">penalty&nbsp;</td>
            <td class="value">&#x27;l2&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('dual',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">dual&nbsp;</td>
            <td class="value">False</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('tol',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">tol&nbsp;</td>
            <td class="value">0.0001</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('C',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">C&nbsp;</td>
            <td class="value">1.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('fit_intercept',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">fit_intercept&nbsp;</td>
            <td class="value">True</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('intercept_scaling',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">intercept_scaling&nbsp;</td>
            <td class="value">1</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('class_weight',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">class_weight&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('random_state',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">random_state&nbsp;</td>
            <td class="value">42</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('solver',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">solver&nbsp;</td>
            <td class="value">&#x27;lbfgs&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_iter',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_iter&nbsp;</td>
            <td class="value">100</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('multi_class',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">multi_class&nbsp;</td>
            <td class="value">&#x27;deprecated&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('verbose',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">verbose&nbsp;</td>
            <td class="value">0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('warm_start',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">warm_start&nbsp;</td>
            <td class="value">False</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_jobs',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_jobs&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('l1_ratio',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">l1_ratio&nbsp;</td>
            <td class="value">None</td>
        </tr>

                  </tbody>
                </table>
            </details>
        </div>
    </div></div></div></div></div><script>function copyToClipboard(text, element) {
    // Get the parameter prefix from the closest toggleable content
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const fullParamName = paramPrefix ? `${paramPrefix}${text}` : text;

    const originalStyle = element.style;
    const computedStyle = window.getComputedStyle(element);
    const originalWidth = computedStyle.width;
    const originalHTML = element.innerHTML.replace('Copied!', '');

    navigator.clipboard.writeText(fullParamName)
        .then(() => {
            element.style.width = originalWidth;
            element.style.color = 'green';
            element.innerHTML = "Copied!";

            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        })
        .catch(err => {
            console.error('Failed to copy:', err);
            element.style.color = 'red';
            element.innerHTML = "Failed!";
            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        });
    return false;
}

document.querySelectorAll('.fa-regular.fa-copy').forEach(function(element) {
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const paramName = element.parentElement.nextElementSibling.textContent.trim();
    const fullParamName = paramPrefix ? `${paramPrefix}${paramName}` : paramName;

    element.setAttribute('title', fullParamName);
});
</script></body>




```python

```


```python
y_pred = LG_MODEL.predict(X_test)
print("Logistic regression model")
report = classification_report(y_test, y_pred)
matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(matrix, annot = True, fmt = "g")
plt.show()
print(report)
```

    Logistic regression model
    


    
![png](output_47_1.png)
    


                  precision    recall  f1-score   support
    
               0       0.58      0.67      0.62       181
               1       0.68      0.59      0.64       217
    
        accuracy                           0.63       398
       macro avg       0.63      0.63      0.63       398
    weighted avg       0.64      0.63      0.63       398
    
    


```python
from sklearn.metrics import classification_report, confusion_matrix

```


```python
## To train the models 
from sklearn.metrics import accuracy_score 
```


```python
results={}
```


```python
Randomforest = RandomForestClassifier(class_weight='balanced', random_state=42)

## model training 
Randomforest.fit(X_train, y_train)
print("Random forest model")
y_pred = Randomforest.predict(X_test)
report = classification_report(y_test, y_pred)
matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(matrix, annot = True, fmt="g")
plt.show()
print(report)

```

    random forest model
    


    
![png](output_51_1.png)
    


                  precision    recall  f1-score   support
    
               0       0.82      0.90      0.86       181
               1       0.91      0.83      0.87       217
    
        accuracy                           0.86       398
       macro avg       0.86      0.87      0.86       398
    weighted avg       0.87      0.86      0.86       398
    
    


```python
GradientBoosting = GradientBoostingClassifier(random_state = 42)

## model training 
GradientBoosting.fit(X_train, y_train)
print("Gradient boosting model")
y_pred = GradientBoosting.predict(X_test)
report = classification_report(y_test, y_pred)
matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(matrix, annot = True, fmt="g")
plt.show()
print(report)
```

    Gradient boosting model
    


    
![png](output_52_1.png)
    


                  precision    recall  f1-score   support
    
               0       0.74      0.83      0.78       181
               1       0.84      0.75      0.79       217
    
        accuracy                           0.79       398
       macro avg       0.79      0.79      0.79       398
    weighted avg       0.79      0.79      0.79       398
    
    


```python
DecisionTree = DecisionTreeClassifier(random_state = 42, class_weight="balanced")
## model training 
DecisionTree.fit(X_train, y_train)
print("Decision tree")
y_pred = DecisionTree.predict(X_test)
report = classification_report(y_test, y_pred)
matrix = confusion_matrix(y_test, y_pred)
accuracy= accuracy_score(y_test, y_pred)
sns.heatmap(matrix, annot = True, fmt="g")
plt.show()
print(report)
```

    Decision tree
    


    
![png](output_53_1.png)
    


                  precision    recall  f1-score   support
    
               0       0.69      0.70      0.70       181
               1       0.75      0.74      0.75       217
    
        accuracy                           0.72       398
       macro avg       0.72      0.72      0.72       398
    weighted avg       0.72      0.72      0.72       398
    
    


```python
XGB_model= XGBClassifier (eval_metric = "mlogloss")
## model training 
XGB_model.fit(X_train, y_train)
print("XGBoost Model")
y_pred = XGB_model.predict(X_test)
report = classification_report(y_test, y_pred)
matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(matrix, annot = True, fmt="g")
plt.show()
print(report)
```

    XGBoost Model
    


    
![png](output_54_1.png)
    


                  precision    recall  f1-score   support
    
               0       0.82      0.87      0.84       181
               1       0.88      0.84      0.86       217
    
        accuracy                           0.85       398
       macro avg       0.85      0.85      0.85       398
    weighted avg       0.85      0.85      0.85       398
    
    

## summary
##The random forest model performs well overall, achieving an accuracy of 86% on the test set, with balanced performance across both classes.

#### For non-churn customers (class 0), the model shows strong recall (0.90), meaning it correctly identifies most customers who stay. Precision is slightly lower at 0.82, indicating some customers predicted as non-churners actually churn.

#### For churn customers (class 1), the model achieves high precision (0.91), so when it predicts a customer will churn, it is usually correct. Recall is a bit lower at 0.83, meaning some churners are missed.

#### The F1-scores are very similar for both classes (0.86–0.87), suggesting a good balance between precision and recall. The macro and weighted averages (~0.86) confirm consistent performance across classes despite slight differences in support.

#### In practical terms, the model is slightly better at avoiding false churn alerts (high precision for class 1) than it is at capturing all churners (lower recall for class 1). Depending on business priorities, you might consider improving recall for churn (e.g., by adjusting the classification threshold) if missing churners is costly.


## Hyper paremeter tuning 


```python
Estimator = RandomForestClassifier(class_weight='balanced', random_state=42)

from sklearn.model_selection import GridSearchCV
```


```python
## fine tuning parameters

parameter_grid = { 'n_estimators':[50,100,200],
                   'max_depth':[0,10,20,30],
                   'min_samples_split':[2,5,10],
                   'min_samples_leaf':[1,2,4]}


```


```python
grid_search = GridSearchCV ( RandomForestClassifier (random_state = 42, class_weight = "balanced"),
                            param_grid = parameter_grid,
                            scoring = 'f1',
                            cv = 5,
                            n_jobs = -1
) 
```


```python
grid_search.fit(X_train, y_train)
```

    C:\Users\CharlesQ\AppData\Local\anaconda3\Lib\site-packages\sklearn\model_selection\_validation.py:516: FitFailedWarning: 
    135 fits failed out of a total of 540.
    The score on these train-test partitions for these parameters will be set to nan.
    If these failures are not expected, you can try to debug them by setting error_score='raise'.
    
    Below are more details about the failures:
    --------------------------------------------------------------------------------
    135 fits failed with the following error:
    Traceback (most recent call last):
      File "C:\Users\CharlesQ\AppData\Local\anaconda3\Lib\site-packages\sklearn\model_selection\_validation.py", line 859, in _fit_and_score
        estimator.fit(X_train, y_train, **fit_params)
        ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "C:\Users\CharlesQ\AppData\Local\anaconda3\Lib\site-packages\sklearn\base.py", line 1358, in wrapper
        estimator._validate_params()
        ~~~~~~~~~~~~~~~~~~~~~~~~~~^^
      File "C:\Users\CharlesQ\AppData\Local\anaconda3\Lib\site-packages\sklearn\base.py", line 471, in _validate_params
        validate_parameter_constraints(
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^
            self._parameter_constraints,
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            self.get_params(deep=False),
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            caller_name=self.__class__.__name__,
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        )
        ^
      File "C:\Users\CharlesQ\AppData\Local\anaconda3\Lib\site-packages\sklearn\utils\_param_validation.py", line 98, in validate_parameter_constraints
        raise InvalidParameterError(
        ...<2 lines>...
        )
    sklearn.utils._param_validation.InvalidParameterError: The 'max_depth' parameter of RandomForestClassifier must be an int in the range [1, inf) or None. Got 0 instead.
    
      warnings.warn(some_fits_failed_message, FitFailedWarning)
    C:\Users\CharlesQ\AppData\Local\anaconda3\Lib\site-packages\sklearn\model_selection\_search.py:1135: UserWarning: One or more of the test scores are non-finite: [       nan        nan        nan        nan        nan        nan
            nan        nan        nan        nan        nan        nan
            nan        nan        nan        nan        nan        nan
            nan        nan        nan        nan        nan        nan
            nan        nan        nan 0.79664593 0.80561649 0.811765
     0.7893061  0.80061543 0.80525634 0.77758637 0.78904915 0.78997643
     0.79055182 0.79482685 0.80187197 0.79019926 0.79679093 0.80691195
     0.7840581  0.78647427 0.78728426 0.7845818  0.78668382 0.78187174
     0.7845818  0.78668382 0.78187174 0.77285178 0.77998357 0.78357341
     0.81034654 0.81631236 0.82769241 0.80918458 0.8169175  0.81829373
     0.78700671 0.7957163  0.79590039 0.80084538 0.8101077  0.81822239
     0.79321201 0.81032836 0.8122736  0.78301902 0.79348797 0.79405419
     0.77587195 0.78969955 0.7943695  0.77587195 0.78969955 0.7943695
     0.78352514 0.79064863 0.78929996 0.80890339 0.81933286 0.82686181
     0.80757894 0.81664421 0.81941935 0.78492694 0.79657154 0.79694425
     0.8037499  0.81287845 0.82098148 0.79614056 0.80767335 0.81521153
     0.78422674 0.79407252 0.79433678 0.77538123 0.7891717  0.79592298
     0.77538123 0.7891717  0.79592298 0.7821918  0.79087376 0.78895932]
      warnings.warn(
    




<style>#sk-container-id-2 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: #000;
  --sklearn-color-text-muted: #666;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-2 {
  color: var(--sklearn-color-text);
}

#sk-container-id-2 pre {
  padding: 0;
}

#sk-container-id-2 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-2 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-2 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-2 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-2 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-2 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-2 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-2 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-2 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-2 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-2 label.sk-toggleable__label {
  cursor: pointer;
  display: flex;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
  align-items: start;
  justify-content: space-between;
  gap: 0.5em;
}

#sk-container-id-2 label.sk-toggleable__label .caption {
  font-size: 0.6rem;
  font-weight: lighter;
  color: var(--sklearn-color-text-muted);
}

#sk-container-id-2 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-2 div.sk-toggleable__content {
  display: none;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  display: block;
  width: 100%;
  overflow: visible;
}

#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-2 div.sk-label label.sk-toggleable__label,
#sk-container-id-2 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-2 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-2 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-2 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-2 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-2 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 0.5em;
  text-align: center;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-2 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-2 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-2 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-2 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}

.estimator-table summary {
    padding: .5rem;
    font-family: monospace;
    cursor: pointer;
}

.estimator-table details[open] {
    padding-left: 0.1rem;
    padding-right: 0.1rem;
    padding-bottom: 0.3rem;
}

.estimator-table .parameters-table {
    margin-left: auto !important;
    margin-right: auto !important;
}

.estimator-table .parameters-table tr:nth-child(odd) {
    background-color: #fff;
}

.estimator-table .parameters-table tr:nth-child(even) {
    background-color: #f6f6f6;
}

.estimator-table .parameters-table tr:hover {
    background-color: #e0e0e0;
}

.estimator-table table td {
    border: 1px solid rgba(106, 105, 104, 0.232);
}

.user-set td {
    color:rgb(255, 94, 0);
    text-align: left;
}

.user-set td.value pre {
    color:rgb(255, 94, 0) !important;
    background-color: transparent !important;
}

.default td {
    color: black;
    text-align: left;
}

.user-set td i,
.default td i {
    color: black;
}

.copy-paste-icon {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NDggNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNy4yIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjUgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTIwOCAwTDMzMi4xIDBjMTIuNyAwIDI0LjkgNS4xIDMzLjkgMTQuMWw2Ny45IDY3LjljOSA5IDE0LjEgMjEuMiAxNC4xIDMzLjlMNDQ4IDMzNmMwIDI2LjUtMjEuNSA0OC00OCA0OGwtMTkyIDBjLTI2LjUgMC00OC0yMS41LTQ4LTQ4bDAtMjg4YzAtMjYuNSAyMS41LTQ4IDQ4LTQ4ek00OCAxMjhsODAgMCAwIDY0LTY0IDAgMCAyNTYgMTkyIDAgMC0zMiA2NCAwIDAgNDhjMCAyNi41LTIxLjUgNDgtNDggNDhMNDggNTEyYy0yNi41IDAtNDgtMjEuNS00OC00OEwwIDE3NmMwLTI2LjUgMjEuNS00OCA0OC00OHoiLz48L3N2Zz4=);
    background-repeat: no-repeat;
    background-size: 14px 14px;
    background-position: 0;
    display: inline-block;
    width: 14px;
    height: 14px;
    cursor: pointer;
}
</style><body><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5,
             estimator=RandomForestClassifier(class_weight=&#x27;balanced&#x27;,
                                              random_state=42),
             n_jobs=-1,
             param_grid={&#x27;max_depth&#x27;: [0, 10, 20, 30],
                         &#x27;min_samples_leaf&#x27;: [1, 2, 4],
                         &#x27;min_samples_split&#x27;: [2, 5, 10],
                         &#x27;n_estimators&#x27;: [50, 100, 200]},
             scoring=&#x27;f1&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" ><label for="sk-estimator-id-2" class="sk-toggleable__label fitted sk-toggleable__label-arrow"><div><div>GridSearchCV</div></div><div><a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.7/modules/generated/sklearn.model_selection.GridSearchCV.html">?<span>Documentation for GridSearchCV</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></div></label><div class="sk-toggleable__content fitted" data-param-prefix="">
        <div class="estimator-table">
            <details>
                <summary>Parameters</summary>
                <table class="parameters-table">
                  <tbody>

        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('estimator',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">estimator&nbsp;</td>
            <td class="value">RandomForestC...ndom_state=42)</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('param_grid',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">param_grid&nbsp;</td>
            <td class="value">{&#x27;max_depth&#x27;: [0, 10, ...], &#x27;min_samples_leaf&#x27;: [1, 2, ...], &#x27;min_samples_split&#x27;: [2, 5, ...], &#x27;n_estimators&#x27;: [50, 100, ...]}</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('scoring',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">scoring&nbsp;</td>
            <td class="value">&#x27;f1&#x27;</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_jobs',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_jobs&nbsp;</td>
            <td class="value">-1</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('refit',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">refit&nbsp;</td>
            <td class="value">True</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('cv',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">cv&nbsp;</td>
            <td class="value">5</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('verbose',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">verbose&nbsp;</td>
            <td class="value">0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('pre_dispatch',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">pre_dispatch&nbsp;</td>
            <td class="value">&#x27;2*n_jobs&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('error_score',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">error_score&nbsp;</td>
            <td class="value">nan</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('return_train_score',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">return_train_score&nbsp;</td>
            <td class="value">False</td>
        </tr>

                  </tbody>
                </table>
            </details>
        </div>
    </div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" ><label for="sk-estimator-id-3" class="sk-toggleable__label fitted sk-toggleable__label-arrow"><div><div>best_estimator_: RandomForestClassifier</div></div></label><div class="sk-toggleable__content fitted" data-param-prefix="best_estimator___"><pre>RandomForestClassifier(class_weight=&#x27;balanced&#x27;, max_depth=20, n_estimators=200,
                       random_state=42)</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" ><label for="sk-estimator-id-4" class="sk-toggleable__label fitted sk-toggleable__label-arrow"><div><div>RandomForestClassifier</div></div><div><a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.7/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a></div></label><div class="sk-toggleable__content fitted" data-param-prefix="best_estimator___">
        <div class="estimator-table">
            <details>
                <summary>Parameters</summary>
                <table class="parameters-table">
                  <tbody>

        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_estimators',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_estimators&nbsp;</td>
            <td class="value">200</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('criterion',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">criterion&nbsp;</td>
            <td class="value">&#x27;gini&#x27;</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_depth',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_depth&nbsp;</td>
            <td class="value">20</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_samples_split',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_samples_split&nbsp;</td>
            <td class="value">2</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_samples_leaf',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_samples_leaf&nbsp;</td>
            <td class="value">1</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_weight_fraction_leaf',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_weight_fraction_leaf&nbsp;</td>
            <td class="value">0.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_features',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_features&nbsp;</td>
            <td class="value">&#x27;sqrt&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_leaf_nodes',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_leaf_nodes&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_impurity_decrease',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_impurity_decrease&nbsp;</td>
            <td class="value">0.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('bootstrap',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">bootstrap&nbsp;</td>
            <td class="value">True</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('oob_score',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">oob_score&nbsp;</td>
            <td class="value">False</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_jobs',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_jobs&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('random_state',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">random_state&nbsp;</td>
            <td class="value">42</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('verbose',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">verbose&nbsp;</td>
            <td class="value">0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('warm_start',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">warm_start&nbsp;</td>
            <td class="value">False</td>
        </tr>


        <tr class="user-set">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('class_weight',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">class_weight&nbsp;</td>
            <td class="value">&#x27;balanced&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('ccp_alpha',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">ccp_alpha&nbsp;</td>
            <td class="value">0.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_samples',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_samples&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('monotonic_cst',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">monotonic_cst&nbsp;</td>
            <td class="value">None</td>
        </tr>

                  </tbody>
                </table>
            </details>
        </div>
    </div></div></div></div></div></div></div></div></div></div><script>function copyToClipboard(text, element) {
    // Get the parameter prefix from the closest toggleable content
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const fullParamName = paramPrefix ? `${paramPrefix}${text}` : text;

    const originalStyle = element.style;
    const computedStyle = window.getComputedStyle(element);
    const originalWidth = computedStyle.width;
    const originalHTML = element.innerHTML.replace('Copied!', '');

    navigator.clipboard.writeText(fullParamName)
        .then(() => {
            element.style.width = originalWidth;
            element.style.color = 'green';
            element.innerHTML = "Copied!";

            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        })
        .catch(err => {
            console.error('Failed to copy:', err);
            element.style.color = 'red';
            element.innerHTML = "Failed!";
            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        });
    return false;
}

document.querySelectorAll('.fa-regular.fa-copy').forEach(function(element) {
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const paramName = element.parentElement.nextElementSibling.textContent.trim();
    const fullParamName = paramPrefix ? `${paramPrefix}${paramName}` : paramName;

    element.setAttribute('title', fullParamName);
});
</script></body>




```python
## to find best parameters
print(f"Best hyperparameters :{grid_search.best_params_}")
```

    Best hyperparameters :{'max_depth': 20, 'min_samples_leaf': 1, 'min_samples_split': 2, 'n_estimators': 200}
    


```python
## To tran the best random forest model 

best_rf_model = grid_search.best_estimator_

```


```python
# to run predictions 

y_pred_best_rf_model = best_rf_model.predict(X_test)
```


```python
##Evaluate the model performance 

print ("Fine tunes Randon Forest classifier")

report = classification_report(y_test,y_pred_best_rf_model )

print(report)
```

    Fine tunes Randon Forest classifier
                  precision    recall  f1-score   support
    
               0       0.84      0.89      0.87       181
               1       0.90      0.86      0.88       217
    
        accuracy                           0.87       398
       macro avg       0.87      0.88      0.87       398
    weighted avg       0.88      0.87      0.87       398
    
    


```python
matrix = confusion_matrix(y_test,y_pred_best_rf_model)
print("Fine tuned random forest model")
sns.heatmap(matrix, annot = True, fmt="g")
plt.xlabel("Prediction")
plt.ylabel("Actual")
plt.show()
print(report)
```

    Fine tuned random forest model
    


    
![png](output_65_1.png)
    


                  precision    recall  f1-score   support
    
               0       0.84      0.89      0.87       181
               1       0.90      0.86      0.88       217
    
        accuracy                           0.87       398
       macro avg       0.87      0.88      0.87       398
    weighted avg       0.88      0.87      0.87       398
    
    


```python
## Roc curve and auc score 
```


```python

from sklearn.metrics import roc_curve, roc_auc_score 


```


```python
## compute probablities for roc 

y_probs = best_rf_model.predict_proba(X_test)[:,1]

fpr, tpr, threshold = roc_curve(y_test, y_probs)
auc_score = roc_auc_score(y_test, y_probs)

plt.figure(figsize = (8,6))
plt.plot(fpr, tpr, label = f"AUC: {auc_score:2f}")
plt.plot([0,1], [0,1], linestyle = "--", color = "gray")
plt.xlabel("False positive rate")
plt.ylabel("True positive rate")
plt.legend(loc = "lower right")
plt.show()
```


    
![png](output_68_0.png)
    


#### The optimised random forest model shows a small but meaningful improvement, with overall accuracy rising to 87% and slightly stronger balance between classes.

#### For non-churn customers (class 0), recall remains high at 0.89, indicating the model still reliably identifies customers who stay. Precision improves to 0.84, suggesting fewer churners are being misclassified as non-churners.

#### For churn customers (class 1), the model maintains strong precision (0.90) while improving recall to 0.86, meaning it now captures more actual churners without sacrificing much accuracy in its predictions.

#### The F1-scores (0.87–0.88) are slightly higher and closely aligned across both classes, reflecting a more even trade-off between precision and recall. The macro and weighted averages (~0.87–0.88) reinforce this consistency.

#### In practical terms, the optimised model is better balanced and more effective at detecting churn, reducing missed churners while still keeping false positives relatively low. This makes it more reliable for retention strategies where identifying at-risk customers is important.


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
